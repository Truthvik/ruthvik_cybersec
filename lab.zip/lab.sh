if [ $# -ne 2 ]; then
    echo "To use the script, you must enter exactly two file names in the format <file1> <file2>"
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "Error: Input file '$1' does not exist."
    exit 1
fi

#input_file="$1"
#output_file="$2"

sed 's/,/ /g' "$1" | awk -F ' ' '{ print $1, $2, $3, $5, $6, $7, $10, $11 }' > "$2"

awk -F ',' '$3=="Bachelor\x27s" { print $1 }' "$1" >> "$2"

awk -F ',' '{
    sum[$6] += $7
    num[$6]++
}
END {
    print "Geography: Average Admission Rate" >> "'$2'"
    for (geography in sum) {
        avg = sum[geography] / num[geography]
        print geography ": " avg >> "'$2'"
    }
}' "$1"

awk -F ',' 'NR > 1 {
    earning[$1] = $14
}
END {
    print "Top Five Colleges by MedianEarnings" >> "'$2'"
    for (name in earning) {
        print name ": " earning[name]
    }
}' "$1" | sort -t ':' -k 2 -nr | head -n 5 >> "$2"